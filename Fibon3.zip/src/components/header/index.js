function Header () {
	// vars
	const $body = document.querySelector('body')
	const $header = document.querySelector('.header')
	const $menu = document.querySelector('.header__menu')
	const $openButton = document.querySelector('.hamburguer')
	const $itemsParent = document.querySelectorAll('li.menu-itehas-children > a')

	/**
	 * Click events to open/close submenus in mobile
	 */
	const toggleSubMenuMobile = () => {
		// iterating menu's item
		$itemsParent.forEach($item => {
			$item.addEventListener('click', e => {
				const $currentOpenItem = $header.querySelector('li.js--open')

				// reset event
				e.preventDefault()

				// reset items
				if ($currentOpenItem && $item.parentElement !== $currentOpenItem) {
					$currentOpenItem.classList.toggle('js--open')
				}

				// active current item
				$item.parentElement.classList.toggle('js--open')
			})
		})
	}

	/**
	 * Click event to open/close menu mobile
	 */
	const toggleMenuMobile = () => {
		$openButton.addEventListener('click', e => {
			// reset body
			if ($body.style.overflow === 'hidden') {
				$body.style.removeProperty('overflow')
			} else {
				// Open menu
				$body.style.overflow = 'hidden'
			}

			// open menu
			$menu.classList.toggle('js--open')

			// active button
			$openButton.classList.toggle('js--active')
		})
	}

	/**
	 * Detect if media query is match to current window's width
	 * @param {object} media media query
	 */
	// const onlyMobile = (media) => {
	// 	if (media.matches) {
	// 		toggleMenuMobile()
	// 		toggleSubMenuMobile()
	// 	}
	// }

	/**
	 * Set data scroll to header element
	 */
	// const setDataScroll = () => {
	// 	window.addEventListener('scroll', () => {
	// 		$header.dataset.scroll = window.scrollY
	// 	})
	// }

	const onResize = () => {
		addEventListener('resize', _ => {
			if (window.innerWidth > 1024) {

				$menu.classList.remove('js--open')
				$openButton.classList.remove('js--active')
				$body.style.removeProperty('overflow')
			}
		})
	}
	/**
	 * Function to init methods
	 */
	(function init() {
		if ($header && $menu && $openButton) {
			// setLabelOnSearchEvent()
			// const mediaQuery = window.matchMedia('(max-width: 1023px)')

			// to mobile
			// mediaQuery.addListener(onlyMobile)
			// onlyMobile(mediaQuery)

			toggleMenuMobile()
			toggleSubMenuMobile()

			// to mobil & desktop
			// setDataScroll()

			onResize()
		}
	})()
}

// init header
Header()
