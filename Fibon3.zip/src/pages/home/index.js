console.log('#MAIN PAGE JS')
import './js/hero.swiper'
// import Swiper from 'swiper';
// import { Navigation } from 'swiper/modules';

// init Swiper:
// new Swiper("#swiperHero", {
//     modules: [Navigation],
//     navigation: {
//       nextEl: ".swiper-button-next",
//       prevEl: ".swiper-button-prev",
//     },
// });